
import Head from 'next/head';

export default function Dashboard() {
  return (
    <div className="min-h-screen bg-gray-900 text-white p-6">
      <Head>
        <title>Admin - seubank</title>
      </Head>
      <h1 className="text-3xl font-bold mb-6">Painel Administrativo</h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-yellow-500 text-black p-6 rounded-xl shadow-lg">
          <h2 className="text-xl font-bold">Saldo Total</h2>
          <p className="text-3xl mt-2">R$ 15.000,00</p>
        </div>

        <div className="bg-white text-black p-6 rounded-xl shadow-lg">
          <h2 className="text-xl font-bold">Usuários Ativos</h2>
          <p className="text-3xl mt-2">182</p>
        </div>

        <div className="bg-yellow-200 text-black p-6 rounded-xl shadow-lg">
          <h2 className="text-xl font-bold">Transações Hoje</h2>
          <p className="text-3xl mt-2">248</p>
        </div>
      </div>
    </div>
  );
}
