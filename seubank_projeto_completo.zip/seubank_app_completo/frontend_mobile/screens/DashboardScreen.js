
import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export default function DashboardScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Saldo Atual</Text>
      <Text style={styles.saldo}>R$ 1.500,50</Text>
      <Text style={styles.transacoes}>Últimas transações:</Text>
      <Text style={styles.item}>+ R$ 500 - Pix recebido</Text>
      <Text style={styles.item}>- R$ 200 - Pagamento conta</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#000',
    padding: 20
  },
  title: {
    fontSize: 28,
    color: '#FFD700',
    marginBottom: 10
  },
  saldo: {
    fontSize: 36,
    color: '#fff',
    marginBottom: 20
  },
  transacoes: {
    fontSize: 20,
    color: '#FFD700',
    marginBottom: 10
  },
  item: {
    fontSize: 16,
    color: '#fff'
  }
});
