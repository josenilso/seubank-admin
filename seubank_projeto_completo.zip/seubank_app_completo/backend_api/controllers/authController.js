
const jwt = require('jsonwebtoken');

exports.login = (req, res) => {
    const { email, senha } = req.body;
    if (email === 'admin@seubank.com' && senha === '123456') {
        const token = jwt.sign({ id: 1 }, 'secreto123', { expiresIn: '1h' });
        return res.json({ token });
    }
    return res.status(401).send('Credenciais inválidas');
};
