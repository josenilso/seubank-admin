
exports.getDashboard = (req, res) => {
    res.json({
        saldo: 1500.50,
        transacoes: [
            { tipo: 'entrada', valor: 500, descricao: 'Pix recebido' },
            { tipo: 'saida', valor: 200, descricao: 'Pagamento conta' }
        ]
    });
};
